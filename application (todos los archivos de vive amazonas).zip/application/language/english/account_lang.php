<?

// Textos para la pagina "Mi cuenta"
$lang["account_title"] = "My account";
$lang["account_big_title"] = "Update Data";
$lang["account_personal_data"] = "Personal Data";
$lang["account_personal_info"] = "Personal Information";
$lang["account_phone"] = "Telephone";
$lang["account_cellphone"] = "Movil";
$lang["account_name"] = "Name";
$lang["account_lastname"] = "Lastname";
$lang["account_email"] = "Email";
$lang["account_address"] = "Address";
$lang["account_location"] = "Location";
$lang["account_department"] = "State";
$lang["account_city"] = "City";
$lang["account_password"] = "Password";
$lang["account_change_password"] = "Change password";
$lang["account_lenguague"] = "Language";
$lang["account_button_save"] = "Save changes";
// Fin textos para la pagina "Mi cuenta"