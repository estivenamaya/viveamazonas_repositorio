<?

// Textos para pagina de "Carrito"
$lang["cart_product"] = "Product";
$lang["cart_quantity"] = "Quantity";
$lang["cart_price"] = "Price/U";
$lang["cart_package"] = "Package";
$lang["cart_continue_shopping"] = "Continue shopping";
$lang["cart_button_pay"] = "Pay";
$lang["cart_button_confirm"] = "Confirm";
$lang["cart_pay_subtitle"] = "Choose a payment method";
$lang["cart_pay_payu"] = "PayU";
$lang["cart_pay_national"] = "PSE";
$lang["cart_pay_bank"] = "Debit/Credit Card";