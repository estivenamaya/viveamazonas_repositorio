<?

// Textos para la pagina de actividad (Ver producto)
$lang["activity_button_buy"] = "Buy";
$lang["activity_price"] = "Price";
$lang["activity_option"] = "Opcion";
$lang["activity_add"] = "Add";
$lang["activity_duration"] = "Duration";
$lang["activity_fates"] = "Destinatios";
$lang["activity_important"] = "Important";
$lang["activity_routes"] = "Route";
$lang["activity_comment_text"] = "Write a comment and rate your experience";
$lang["activity_comment_button"] = "Save";
$lang["activity_comments_title"] = "Comments on this activity";
$lang["activity_comments_error"] = "";
// Fin textos para la pagina de actividad (Ver producto)