<?php

// Textos pagina de inicio
$lang["index_title"] = "Amazonas is waiting for you !!";
$lang["index_subtitle"] = "Enjoy our plans";
// Fin textos pagina de inicio

// Textos suscripcion a boletin
$lang["index_bulletin_title"] = "SUBSCRIBE TO <strong>OUR BULLETINS</strong>";
$lang["index_bulletin_subtitle"] = "Subscribe to our bulletins and be the first to receive our exclusive email offers.";
$lang["index_bulletin_button"] = "SUBSCRIBE";
$lang["index_bulletin_email_placeholder"] = "Email";
// Fin textos suscripcion a boletin

// Textos testimonios
$lang["index_testimony_title"] = "Testimonials";
$lang["index_testimony_subtitle"] = "OUR CLIENTS THINK";
// Fin textos testimonios