<?

// Textos para la pagina de pedido realizados (Historial de compras)
$lang["record_order"] = "Order";
$lang["record_type"] = "Type";
$lang["record_name"] = "Name";
$lang["record_activity"] = "Activity";
$lang["record_quantity"] = "Quantity";
$lang["record_precio"] = "Price/U";
$lang["record_package"] = "Package";
// Fin textos para la pagina de pedido realizados (Historial de compras)