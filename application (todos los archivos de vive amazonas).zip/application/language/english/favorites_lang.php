<?

// Textos para pagina de favoritos
$lang["favorites_activities"] = "Activities";
$lang["favorites_fates"] = "Destinations";