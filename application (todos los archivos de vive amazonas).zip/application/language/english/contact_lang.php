<?

// Textos de pagina de contacto
$lang["contact_description"] = "If you need any aditional information, give us your contact data and we will get in touch with you";
$lang["contact_name"] = "Full name";
$lang["contact_email"] = "Email";
$lang["contact_message"] = "Message";
$lang["contact_button_send"] = "Send";
// Fin textos de pagina de contacto