<?php

// Textos pagina de inicio
$lang["index_title"] = "El Amazonas te está Esperando!!";
$lang["index_subtitle"] = "Disfruta de nuestros planes";
// Fin textos pagina de inicio

// Textos suscripcion a boletin
$lang["index_bulletin_title"] = "SUSCRÍBASE A <strong>NUESTRO BOLETÍN</strong>";
$lang["index_bulletin_subtitle"] = "Suscríbase a nuestro boletín y sea el primero en recibir ofertas en su correo electrónico.";
$lang["index_bulletin_button"] = "SUSCRIBIRSE";
$lang["index_bulletin_email_placeholder"] = "Correo electronico";
// Fin textos suscripcion a boletin

// Textos testimonios
$lang["index_testimony_title"] = "Testimonios";
$lang["index_testimony_subtitle"] = "NUESTROS CLIENTES OPINAN";
// Fin textos testimonios