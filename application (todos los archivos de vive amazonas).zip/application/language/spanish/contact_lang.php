<?

// Textos de pagina de contacto
$lang["contact_description"] = "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.";
$lang["contact_name"] = "Nombre completo";
$lang["contact_email"] = "Correo electronico";
$lang["contact_message"] = "Mensaje";
$lang["contact_button_send"] = "Enviar";
// Fin textos de pagina de contacto