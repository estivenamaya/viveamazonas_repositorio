<?

// Textos para la pagina de actividad (Ver producto)
$lang["activity_button_buy"] = "Comprar";
$lang["activity_price"] = "Precio";
$lang["activity_option"] = "Opcion";
$lang["activity_add"] = "Agregar";
$lang["activity_duration"] = "Duracion";
$lang["activity_fates"] = "Destinos";
$lang["activity_important"] = "Importante";
$lang["activity_routes"] = "Ruta";
$lang["activity_comment_text"] = "Escribe un comentario y califica segun tu experiencia con esta actividad";
$lang["activity_comment_button"] = "Guardar";
$lang["activity_comments_title"] = "Comentarios de usuarios que realizaron esta actividad";
$lang["activity_comments_error"] = "No se han encontrado comentarios para esta actividad";
// Fin textos para la pagina de actividad (Ver producto)