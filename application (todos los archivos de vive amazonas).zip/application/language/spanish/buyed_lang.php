<?

// Textos para la pagina de pedido realizados (Historial de compras)
$lang["record_order"] = "Pedido";
$lang["record_type"] = "Tipo";
$lang["record_name"] = "Nombre";
$lang["record_activity"] = "Actividad";
$lang["record_quantity"] = "Cantidad";
$lang["record_precio"] = "Precio/U";
$lang["record_package"] = "Paquete";
// Fin textos para la pagina de pedido realizados (Historial de compras)