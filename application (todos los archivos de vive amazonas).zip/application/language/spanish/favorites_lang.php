<?

// Textos para pagina de favoritos
$lang["favorites_activities"] = "Actividades";
$lang["favorites_fates"] = "Destinos";