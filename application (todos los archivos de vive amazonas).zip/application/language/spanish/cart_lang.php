<?

// Textos para pagina de "Carrito"
$lang["cart_product"] = "Producto";
$lang["cart_quantity"] = "Cantidad";
$lang["cart_price"] = "Precio/U";
$lang["cart_package"] = "Paquete";
$lang["cart_continue_shopping"] = "Continuar comprando";
$lang["cart_button_pay"] = "Realizar pago";
$lang["cart_button_confirm"] = "Confirmar";
$lang["cart_pay_subtitle"] = "Por favor elija un metodo de pago para su compra";
$lang["cart_pay_payu"] = "Pago en Colombia (PayU)";
$lang["cart_pay_national"] = "Giro nacional";
$lang["cart_pay_paypal"] = "Pago fuera de Colombia (PayPal)";
$lang["cart_pay_bank"] = "Transaccion bancaria";
