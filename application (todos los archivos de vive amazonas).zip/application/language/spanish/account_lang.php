<?

// Textos para la pagina "Mi cuenta"
$lang["account_title"] = "Mi cuenta";
$lang["account_big_title"] = "Actualizar datos";
$lang["account_personal_data"] = "Datos personales";
$lang["account_personal_info"] = "Informacion personales";
$lang["account_phone"] = "Telefono";
$lang["account_cellphone"] = "Movil";
$lang["account_name"] = "Nombre";
$lang["account_lastname"] = "Apellidos";
$lang["account_email"] = "Correo electronico";
$lang["account_address"] = "Direccion";
$lang["account_location"] = "Ubicacion";
$lang["account_department"] = "Departamento";
$lang["account_city"] = "Ciudad";
$lang["account_password"] = "Contraseña";
$lang["account_change_password"] = "Cambiar contraseña";
$lang["account_lenguague"] = "Idioma predeterminado";
$lang["account_button_save"] = "Guardar cambios";
// Fin textos para la pagina "Mi cuenta"