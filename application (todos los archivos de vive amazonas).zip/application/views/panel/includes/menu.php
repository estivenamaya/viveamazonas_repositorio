
                <ul class="list-unstyled side-menu">
                    <li class="active">
                        <a class="sa-side-home" href="<?= base_url() ?>panel/main">
                            <span class="menu-item">Inicio</span>
                        </a>
                    </li>
                     <li class="dropdown">
                        <a class="sa-side-form"  href="<?= base_url() ?>producto/lista">
                            <span class="menu-item">Productos</span>
                        </a>
                        <ul class="list-unstyled menu-item">
                            <li><a href="<?= base_url() ?>producto/lista">Lista de productos</a></li>
                            <li><a href="<?= base_url() ?>producto/agregar">Agregar producto</a></li>
                        </ul>
                    </li>
                    <li class="dropdown">
                        <a class="sa-side-form"  href="<?= base_url() ?>slide/lista">
                            <span class="menu-item">Galería principal</span>
                        </a>
                    </li>
                    <li class="dropdown">
                        <a class="sa-side-form"  href="<?= base_url() ?>contenido/lista">
                            <span class="menu-item">Contenidos</span>
                        </a>
                        <ul class="list-unstyled menu-item">
                            <li><a href="<?= base_url() ?>contenido/lista">Lista de contenidos</a></li>
                            <li><a href="<?= base_url() ?>contenido/agregar_contenido">Agregar contenido</a></li>
                        </ul>
                    </li>
                    <li class="dropdown">
                        <a class="sa-side-form"  href="<?= base_url() ?>cliente/lista">
                            <span class="menu-item">Clientes</span>
                        </a>
                    </li>
                    <li class="dropdown">
                        <a class="sa-side-form"  href="<?= base_url() ?>pedido/lista">
                            <span class="menu-item">Pedidos</span>
                        </a>
                    </li>
                </ul>
