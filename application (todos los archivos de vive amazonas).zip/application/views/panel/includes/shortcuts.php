             <!-- Shortcuts -->
                <div class="block-area shortcut-area">
                    <a class="shortcut tile" href="<?= base_url() ?>producto/lista">
                        <img src="<?= base_url() ?>resources/panel/img/shortcuts/products.png" alt="">
                        <small class="t-overflow">Productos</small>
                    </a>
                    <a class="shortcut tile" href="<?= base_url() ?>contenido/lista">
                        <img src="<?= base_url() ?>resources/panel/img/shortcuts/texto.png" alt="">
                        <small class="t-overflow">Contenidos</small>
                    </a>
                    <a class="shortcut tile" href="<?= base_url() ?>slide/lista">
                        <img src="<?= base_url() ?>resources/panel/img/shortcuts/fotos.png" alt="">
                        <small class="t-overflow">Galería principal</small>
                    </a>
                    <a class="shortcut tile" href="<?= base_url() ?>cliente/lista">
                        <img src="<?= base_url() ?>resources/panel/img/shortcuts/estudiantes.png" alt="">
                        <small class="t-overflow">Clientes</small>
                    </a>
                    <a class="shortcut tile" href="<?= base_url() ?>pedido/lista">
                        <img src="<?= base_url() ?>resources/panel/img/shortcuts/servicios.png" alt="">
                        <small class="t-overflow">Pedidos</small>
                    </a>
                </div>
     