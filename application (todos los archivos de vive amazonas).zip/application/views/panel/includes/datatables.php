<?php
/**
 * Created by PhpStorm.
 * User: Nikollai Hernandez
 * Date: 23/05/2016
 * Time: 03:54 PM
 */
?>
<!-- Javascript variables -->
<script type="text/javascript">
    var base_url = '<?= base_url() ?>';
</script>

<!-- Datatables -->
<script src="<?= base_url(); ?>/resources/panel/js/theme/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?= base_url(); ?>/resources/panel/js/theme/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<script src="<?= base_url(); ?>/resources/panel/js/theme/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
<script src="<?= base_url(); ?>/resources/panel/js/theme/datatables.net-buttons-bs/js/buttons.bootstrap.min.js"></script>
<script src="<?= base_url(); ?>/resources/panel/js/theme/datatables.net-buttons/js/buttons.flash.min.js"></script>
<script src="<?= base_url(); ?>/resources/panel/js/theme/datatables.net-buttons/js/buttons.html5.min.js"></script>
<script src="<?= base_url(); ?>/resources/panel/js/theme/datatables.net-buttons/js/buttons.print.min.js"></script>
<script src="<?= base_url(); ?>/resources/panel/js/theme/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js"></script>
<script src="<?= base_url(); ?>/resources/panel/js/theme/datatables.net-keytable/js/dataTables.keyTable.min.js"></script>
<script src="<?= base_url(); ?>/resources/panel/js/theme/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
<script src="<?= base_url(); ?>/resources/panel/js/theme/datatables.net-responsive-bs/js/responsive.bootstrap.js"></script>
<script src="<?= base_url(); ?>/resources/panel/js/theme/datatables.net-scroller/js/datatables.scroller.min.js"></script>
