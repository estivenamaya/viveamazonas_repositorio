
        <!-- Javascript Libraries -->


        <!-- Bootstrap -->
        <script src="<?= base_url() ?>resources/panel/js/bootstrap.min.js"></script>

        <!-- Categorias -->
        <script src="<?= base_url() ?>resources/panel/js/categorias.js"></script>

        <!-- Ubicacion -->
        <script src="<?= base_url() ?>resources/panel/js/ubicaciones.js"></script>
        
        <!-- UX -->
        <script src="<?= base_url() ?>resources/panel/js/scroll.min.js"></script> <!-- Custom Scrollbar -->

        <!-- Custom Theme Scripts -->
        <script src="<?= base_url(); ?>/resources/panel/js/theme/custom.js"></script>

        <!-- jQuery autocomplete -->
        <script src="<?= base_url(); ?>/resources/panel/js/theme/devbridge-autocomplete/dist/jquery.autocomplete.min.js"></script>

        <!-- Javascript Libraries -->
        <script src="<?= base_url() ?>resources/plugins/ckeditor/ckeditor.js"></script>
        <script src="<?= base_url() ?>resources/plugins/message/jquery.toastmessage.js"></script>

        <!-- bootstrap-wysiwyg -->
        <script src="<?= base_url(); ?>/resources/panel/js/theme/bootstrap-wysiwyg/js/bootstrap-wysiwyg.min.js"></script>
        <script src="<?= base_url(); ?>/resources/panel/js/theme/jquery.hotkeys/jquery.hotkeys.js"></script>
        <script src="<?= base_url(); ?>/resources/panel/js/theme/google-code-prettify/src/prettify.js"></script>

        <!-- Dropzone.js -->
        <script src="<?= base_url(); ?>/resources/panel/js/theme/dropzone/dist/min/dropzone.min.js"></script>


