<!DOCTYPE html">
<html>
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
      <title>Vive amazonas</title>
      <meta name="description" content="Default Description"/>
      <meta name="keywords" content="Varien, E-commerce"/>
      <!-- jQuery -->
      <!-- <script src="<?= base_url() ?>resources/panel/js/jquery.min.js"></script> <!-- jQuery Library -->
     <!--  <script src="<?= base_url() ?>resources/panel/js/jquery-ui.min.js"></script>  --><!-- jQuery UI -->
      <link rel="icon" href="<?= base_url() ?>resources/site/skin/galabigshop/favicon.ico" type="image/x-icon"/>
      <link rel="shortcut icon" href="<?= base_url() ?>resources/site/skin/galabigshop/favicon.ico" type="image/x-icon"/>
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
     
      <!-- =========== Main Style =========== -->
      <link href="<?= base_url() ?>resources/site/css/style.min.css" rel="stylesheet" type="text/css"/>
      <link href="<?= base_url() ?>resources/site/css/custom.css" rel="stylesheet" type="text/css"/>
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
    
      <link href="http://fonts.googleapis.com/css?family=Roboto:100,200,300,400,500,600,700,800,900,1000&amp;subset=latin,cyrillic-ext,cyrillic,greek-ext,greek,vietnamese,latin-ext" rel="stylesheet" type="text/css"/>
      <style type="text/css"></style>
      
      <!-- <div class="content-add-car">
          <div class="addcar-header">
            <h2>Producto añadido al carrito</h2>
          </div>
          <button class="btn-addcar cc"><i class="fa fa-tags" aria-hidden="true"></i>Continuar comprando</button>
          <button onclick="goToLink('<?= base_url(); ?>main/carrito');" class="btn-addcar gc"><i class="fa fa-shopping-cart" aria-hidden="true"></i>Ver carrito</button>
      </div> -->
    </head>

    <script type="text/javascript">
       var site_url = '<?= base_url() ?>';
    </script>
