<!DOCTYPE html>
<html lang="es">
 <head>
 <title>Mi titulo</title>
 <meta http-equiv="Content-type" content="text/html; charset=utf-8" />
</head>
 <body>
    <img src="<?= base_url(); ?>resources/site/images/coming-soon.jpg">
</body>
</html>

<style type="text/css">
	img{
		width: 100%;

	}

	html, body{
		width: 100%;
		height: 100%;
		overflow: hidden;
		margin: 0;
		padding: 0;
	}
</style>